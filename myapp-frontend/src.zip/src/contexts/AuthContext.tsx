import React, { createContext, useContext, useState, useEffect, ReactNode } from 'react';
import toast from 'react-hot-toast';
import { authAPI } from '../services/api';

interface User {
  id: string;
  name: string;
  email: string;
  role: 'student' | 'admin';
  enrolledCourses: string[];
  completedCourses: string[];
  progress: { [courseId: string]: string[] };
  mobile?: string;
  avatar?: string;
  joinedDate?: string;
}

interface AuthContextType {
  user: User | null;
  login: (email: string, password: string) => Promise<boolean>;
  logout: () => void;
  enrollInCourse: (courseId: string, courseName: string) => void;
  markTopicComplete: (courseId: string, topicId: string) => void;
  isTopicComplete: (courseId: string, topicId: string) => boolean;
  updateUserProfile: (userData: Partial<User>) => void;
  loading: boolean;
}

const AuthContext = createContext<AuthContextType | undefined>(undefined);

export const useAuth = () => {
  const context = useContext(AuthContext);
  if (!context) {
    throw new Error('useAuth must be used within an AuthProvider');
  }
  return context;
};

export const AuthProvider: React.FC<{ children: ReactNode }> = ({ children }) => {
  const [user, setUser] = useState<User | null>(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    // Check for saved user on app start
    const initializeAuth = async () => {
      try {
        const savedUser = localStorage.getItem('user');
        const token = localStorage.getItem('token');
        
        if (savedUser && token) {
          const userData = JSON.parse(savedUser);
          
          // Verify token is still valid (optional - can call API to verify)
          setUser(userData);
        }
      } catch (error) {
        console.error('Error initializing auth:', error);
        // Clear corrupted data
        localStorage.removeItem('user');
        localStorage.removeItem('token');
      } finally {
        setLoading(false);
      }
    };

    initializeAuth();
  }, []);

  const login = async (email: string, password: string): Promise<boolean> => {
    try {
      setLoading(true);
      
      // ✅ SPECIAL ADMIN LOGINS (Hardcoded for development)
      const adminLogins = [
        { 
          email: 'raviramrajaboina@gmail.com', 
          password: 'ravi+shiva=143', 
          name: 'Ravi Ram Rajaboina',
          mobile: '+91 8688252878',
          role: 'admin' as const
        },
        { 
          email: 'admin@raviram.com', 
          password: 'ravi+shiva123', 
          name: 'Ravi Ram Admin',
          mobile: '+91 8688252878',
          role: 'admin' as const
        },
         
      ];

      // Check if it's a hardcoded admin login
      const admin = adminLogins.find(a => 
        a.email.toLowerCase() === email.toLowerCase() && 
        a.password === password
      );
      
      if (admin) {
        const adminUser: User = {
          id: `admin-${Date.now()}`,
          name: admin.name,
          email: admin.email,
          role: admin.role,
          enrolledCourses: [],
          completedCourses: [],
          progress: {},
          mobile: admin.mobile,
          joinedDate: new Date().toISOString()
        };
        
        setUser(adminUser);
        localStorage.setItem('user', JSON.stringify(adminUser));
        localStorage.setItem('token', `admin-token-${Date.now()}`);
        
        toast.success(`🚀 Welcome Admin ${admin.name}!`);
        setLoading(false);
        return true;
      }

      // ✅ Try actual API login first
      try {
        console.log('🔄 Attempting API login...');
        const response = await authAPI.login(email, password); // ✅ FIXED: Direct parameters
        
        if (response && response.user) {
          const userData = response.user;
          const token = response.token;
          
          const apiUser: User = {
            id: userData.id || userData._id || `user-${Date.now()}`,
            name: userData.name || email.split('@')[0],
            email: userData.email || email,
            role: userData.role || 'student',
            enrolledCourses: userData.enrolledCourses || [],
            completedCourses: userData.completedCourses || [],
            progress: userData.progress || {},
            mobile: userData.mobile,
            avatar: userData.avatar,
            joinedDate: userData.joinedDate || new Date().toISOString()
          };
          
          setUser(apiUser);
          localStorage.setItem('user', JSON.stringify(apiUser));
          localStorage.setItem('token', token);
          
          toast.success(`🎉 Welcome back, ${apiUser.name}!`);
          setLoading(false);
          return true;
        }
      } catch (apiError) {
        console.log('API login failed, falling back to demo mode...');
      }

      // ✅ DEMO MODE: Create student account for any email/password
      if (email && password) {
        const studentUser: User = {
          id: `student-${Date.now()}`,
          name: email.split('@')[0].charAt(0).toUpperCase() + email.split('@')[0].slice(1),
          email: email,
          role: 'student',
          enrolledCourses: [],
          completedCourses: [],
          progress: {},
          joinedDate: new Date().toISOString()
        };
        
        setUser(studentUser);
        localStorage.setItem('user', JSON.stringify(studentUser));
        localStorage.setItem('token', `demo-token-${Date.now()}`);
        
        toast.success('🎓 Welcome to Ravi Ram Education! (Demo Mode)');
        setLoading(false);
        return true;
      }
      
      toast.error('❌ Login failed. Please check your credentials.');
      setLoading(false);
      return false;
      
    } catch (error: any) {
      console.error('Login error:', error);
      toast.error(error.message || 'Login failed. Please try again.');
      setLoading(false);
      return false;
    }
  };

  const logout = () => {
    setUser(null);
    localStorage.removeItem('token');
    localStorage.removeItem('user');
    toast.success('👋 Logged out successfully');
  };

  const enrollInCourse = (courseId: string, courseName: string) => {
    if (user && !user.enrolledCourses.includes(courseId)) {
      const updatedUser = {
        ...user,
        enrolledCourses: [...user.enrolledCourses, courseId],
        progress: { 
          ...user.progress, 
          [courseId]: user.progress[courseId] || [] 
        }
      };
      setUser(updatedUser);
      localStorage.setItem('user', JSON.stringify(updatedUser));
      toast.success(`📚 You've started "${courseName}"!`);
    } else if (user) {
      toast('You are already enrolled in this course!');
    }
  };

  const markTopicComplete = (courseId: string, topicId: string) => {
    if (user) {
      const currentProgress = user.progress[courseId] || [];
      if (!currentProgress.includes(topicId)) {
        const updatedProgress = {
          ...user.progress,
          [courseId]: [...currentProgress, topicId]
        };
        
        const updatedUser = { 
          ...user, 
          progress: updatedProgress 
        };
        
        setUser(updatedUser);
        localStorage.setItem('user', JSON.stringify(updatedUser));
        toast.success('✅ Topic completed! 🎉');
        
        // Check if all topics completed (optional)
        const totalTopics = 10; // You can make this dynamic
        if (updatedProgress[courseId].length >= totalTopics) {
          const finalUser = {
            ...updatedUser,
            completedCourses: [...updatedUser.completedCourses, courseId]
          };
          setUser(finalUser);
          localStorage.setItem('user', JSON.stringify(finalUser));
          toast.success('🎊 Course completed! Congratulations!');
        }
      } else {
        toast('Topic already completed!');
      }
    }
  };

  const isTopicComplete = (courseId: string, topicId: string): boolean => {
    return user?.progress[courseId]?.includes(topicId) || false;
  };

  const updateUserProfile = (userData: Partial<User>) => {
    if (user) {
      const updatedUser = { ...user, ...userData };
      setUser(updatedUser);
      localStorage.setItem('user', JSON.stringify(updatedUser));
      toast.success('Profile updated successfully!');
    }
  };

  const value: AuthContextType = {
    user,
    login,
    logout,
    enrollInCourse,
    markTopicComplete,
    isTopicComplete,
    updateUserProfile,
    loading
  };

  return (
    <AuthContext.Provider value={value}>
      {children}
    </AuthContext.Provider>
  );
};