import React, { useState } from 'react';
import { Play, Copy, RotateCcw } from 'lucide-react';
import toast from 'react-hot-toast';

interface CodePlaygroundProps {
  initialCode: string;
  language: string;
}

const CodePlayground: React.FC<CodePlaygroundProps> = ({ initialCode, language }) => {
  const [code, setCode] = useState(initialCode);
  const [output, setOutput] = useState('');
  const [isRunning, setIsRunning] = useState(false);

  const runCode = () => {
    setIsRunning(true);
    setOutput('');

    // Simulate code execution
    setTimeout(() => {
      try {
        if (language === 'python') {
          // Simple Python interpreter simulation
          const lines = code.split('\n');
          let result = '';
          
          for (const line of lines) {
            const trimmedLine = line.trim();
            if (trimmedLine.startsWith('print(')) {
              const match = trimmedLine.match(/print\((.*)\)/);
              if (match) {
                const content = match[1].replace(/['"]/g, '');
                result += content + '\n';
              }
            }
          }
          
          setOutput(result || 'Code executed successfully!');
        } else {
          setOutput('Code executed successfully!\n(Note: This is a simulated output)');
        }
      } catch (error) {
        setOutput(`Error: ${error}`);
      } finally {
        setIsRunning(false);
      }
    }, 1000);
  };

  const copyCode = () => {
    navigator.clipboard.writeText(code);
    toast.success('Code copied to clipboard!');
  };

  const resetCode = () => {
    setCode(initialCode);
    setOutput('');
    toast.success('Code reset to original!');
  };

  return (
    <div className="bg-white dark:bg-gray-800 rounded-lg border border-gray-200 dark:border-gray-700 overflow-hidden">
      {/* Header */}
      <div className="bg-gray-50 dark:bg-gray-700 px-4 py-3 border-b border-gray-200 dark:border-gray-600">
        <div className="flex items-center justify-between">
          <div className="flex items-center space-x-2">
            <div className="flex space-x-2">
              <div className="w-3 h-3 bg-red-400 rounded-full"></div>
              <div className="w-3 h-3 bg-yellow-400 rounded-full"></div>
              <div className="w-3 h-3 bg-green-400 rounded-full"></div>
            </div>
            <span className="text-sm font-medium text-gray-600 dark:text-gray-400 ml-4">
              {language} playground
            </span>
          </div>
          <div className="flex items-center space-x-2">
            <button
              onClick={copyCode}
              className="p-2 text-gray-600 dark:text-gray-400 hover:text-gray-800 dark:hover:text-gray-200 transition-colors"
              title="Copy code"
            >
              <Copy className="h-4 w-4" />
            </button>
            <button
              onClick={resetCode}
              className="p-2 text-gray-600 dark:text-gray-400 hover:text-gray-800 dark:hover:text-gray-200 transition-colors"
              title="Reset code"
            >
              <RotateCcw className="h-4 w-4" />
            </button>
            <button
              onClick={runCode}
              disabled={isRunning}
              className="flex items-center px-4 py-2 bg-green-600 text-white rounded-lg hover:bg-green-700 transition-colors disabled:opacity-50 disabled:cursor-not-allowed"
            >
              <Play className="h-4 w-4 mr-2" />
              {isRunning ? 'Running...' : 'Run Code'}
            </button>
          </div>
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2">
        {/* Code Editor */}
        <div className="p-4">
          <h4 className="text-sm font-medium text-gray-700 dark:text-gray-300 mb-2">Code Editor</h4>
          <textarea
            value={code}
            onChange={(e) => setCode(e.target.value)}
            className="w-full h-64 p-3 font-mono text-sm bg-gray-900 text-green-400 rounded-lg resize-none focus:outline-none focus:ring-2 focus:ring-blue-500"
            placeholder="Write your code here..."
          />
        </div>

        {/* Output */}
        <div className="p-4 bg-gray-50 dark:bg-gray-700 lg:border-l border-gray-200 dark:border-gray-600">
          <h4 className="text-sm font-medium text-gray-700 dark:text-gray-300 mb-2">Output</h4>
          <div className="h-64 p-3 bg-gray-900 text-gray-100 rounded-lg overflow-auto font-mono text-sm">
            {isRunning ? (
              <div className="flex items-center">
                <div className="animate-spin rounded-full h-4 w-4 border-b-2 border-green-400 mr-2"></div>
                Running code...
              </div>
            ) : (
              <pre className="whitespace-pre-wrap">{output || 'Click "Run Code" to see output'}</pre>
            )}
          </div>
        </div>
      </div>
    </div>
  );
};

export default CodePlayground;