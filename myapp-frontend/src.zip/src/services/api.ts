const API_BASE_URL = 'http://localhost:5000/api';

// Common headers for all requests
const getHeaders = (): HeadersInit => {
    const token = localStorage.getItem('token');
    return {
        'Content-Type': 'application/json',
        ...(token && { 'Authorization': `Bearer ${token}` })
    };
};

// Enhanced API call function with better error handling
export const apiCall = async (endpoint: string, method: string = 'GET', data: any = null) => {
    try {
        const url = `${API_BASE_URL}${endpoint}`;
        const options: RequestInit = {
            method,
            headers: getHeaders(),
        };

        if (data && (method === 'POST' || method === 'PUT' || method === 'PATCH' || method === 'DELETE')) {
            options.body = JSON.stringify(data);
        }

        console.log(`🔄 API Call: ${method} ${url}`, data ? { data } : '');

        const response = await fetch(url, options);
        
        // Handle non-JSON responses
        const contentType = response.headers.get('content-type');
        let result;

        if (contentType && contentType.includes('application/json')) {
            result = await response.json();
        } else {
            const text = await response.text();
            result = { message: text || 'Unexpected response format' };
        }

        console.log(`📊 API Response [${response.status}]:`, result);

        if (!response.ok) {
            // Enhanced error message with status code
            const errorMessage = result.message || 
                               result.error || 
                               `Request failed with status ${response.status}`;
            
            throw new Error(errorMessage);
        }

        return result;
    } catch (error: any) {
        console.error(`❌ API Error (${endpoint}):`, error);
        
        // Enhanced error messages for common cases
        if (error.name === 'TypeError' && error.message.includes('Failed to fetch')) {
            throw new Error('Cannot connect to server. Please check if backend is running.');
        }
        
        if (error.message.includes('500')) {
            throw new Error('Server error. Please try again later.');
        }
        
        throw error;
    }
};

// Enhanced Auth functions with validation
export const authAPI = {
    login: async (email: string, password: string) => {
        // Basic validation
        if (!email || !password) {
            throw new Error('Email and password are required');
        }
        
        if (!email.includes('@')) {
            throw new Error('Please enter a valid email address');
        }

        return await apiCall('/auth/login', 'POST', { email, password });
    },
    
    register: async (userData: any) => {
        if (!userData.email || !userData.password || !userData.name) {
            throw new Error('Name, email and password are required');
        }
        
        return await apiCall('/auth/register', 'POST', userData);
    },
    
    getProfile: async () => {
        return await apiCall('/auth/me', 'GET');
    },

    updateProfile: async (profileData: any) => {
        if (!profileData.name) {
            throw new Error('Name is required');
        }
        
        return await apiCall('/auth/profile', 'PUT', profileData);
    },

    changePassword: async (currentPassword: string, newPassword: string) => {
        if (!currentPassword || !newPassword) {
            throw new Error('Both current and new password are required');
        }
        
        if (newPassword.length < 6) {
            throw new Error('New password must be at least 6 characters long');
        }
        
        return await apiCall('/auth/change-password', 'PUT', { 
            currentPassword, 
            newPassword 
        });
    },

    // New: Verify token validity
    verifyToken: async () => {
        return await apiCall('/auth/verify', 'GET');
    }
};

// User functions
export const userAPI = {
    getUsers: async () => {
        return await apiCall('/users', 'GET');
    },

    getUser: async (userId: string) => {
        if (!userId) {
            throw new Error('User ID is required');
        }
        
        return await apiCall(`/users/${userId}`, 'GET');
    },

    getUserProgress: async () => {
        return await apiCall('/users/progress', 'GET');
    },

    updateUser: async (userId: string, userData: any) => {
        if (!userId) {
            throw new Error('User ID is required');
        }
        
        return await apiCall(`/users/${userId}`, 'PUT', userData);
    },

    // New: Search users
    searchUsers: async (query: string, page: number = 1, limit: number = 10) => {
        const params = new URLSearchParams({
            search: query,
            page: page.toString(),
            limit: limit.toString()
        });
        
        return await apiCall(`/users/search?${params}`, 'GET');
    }
};

// Course functions
export const courseAPI = {
    getCourses: async (filters?: { 
        search?: string; 
        category?: string; 
        level?: string;
        page?: number;
        limit?: number;
        sort?: string;
    } = {}) => {
        const queryParams = new URLSearchParams();
        
        if (filters?.search) queryParams.append('search', filters.search);
        if (filters?.category) queryParams.append('category', filters.category);
        if (filters?.level) queryParams.append('level', filters.level);
        if (filters?.page) queryParams.append('page', filters.page.toString());
        if (filters?.limit) queryParams.append('limit', filters.limit.toString());
        if (filters?.sort) queryParams.append('sort', filters.sort);

        const queryString = queryParams.toString();
        const url = queryString ? `/courses?${queryString}` : '/courses';
        
        return await apiCall(url, 'GET');
    },

    getCourse: async (courseId: string) => {
        if (!courseId) {
            throw new Error('Course ID is required');
        }
        
        return await apiCall(`/courses/${courseId}`, 'GET');
    },

    createCourse: async (courseData: any) => {
        if (!courseData.title || !courseData.description) {
            throw new Error('Title and description are required');
        }
        
        return await apiCall('/courses', 'POST', courseData);
    },

    updateCourse: async (courseId: string, courseData: any) => {
        if (!courseId) {
            throw new Error('Course ID is required');
        }
        
        return await apiCall(`/courses/${courseId}`, 'PUT', courseData);
    },

    enrollCourse: async (courseId: string) => {
        if (!courseId) {
            throw new Error('Course ID is required');
        }
        
        return await apiCall(`/courses/${courseId}/enroll`, 'POST');
    },

    addRating: async (courseId: string, rating: number, comment?: string) => {
        if (!courseId) {
            throw new Error('Course ID is required');
        }
        
        if (rating < 1 || rating > 5) {
            throw new Error('Rating must be between 1 and 5');
        }
        
        return await apiCall(`/courses/${courseId}/rating`, 'POST', { 
            rating, 
            comment: comment || '' 
        });
    },

    // New: Get enrolled courses
    getEnrolledCourses: async () => {
        return await apiCall('/courses/enrolled', 'GET');
    },

    // New: Get course progress
    getCourseProgress: async (courseId: string) => {
        if (!courseId) {
            throw new Error('Course ID is required');
        }
        
        return await apiCall(`/courses/${courseId}/progress`, 'GET');
    }
};

// Admin functions
export const adminAPI = {
    getDashboardStats: async () => {
        return await apiCall('/admin/dashboard', 'GET');
    },

    getAnalytics: async (period?: string) => {
        const url = period ? `/admin/analytics?period=${period}` : '/admin/analytics';
        return await apiCall(url, 'GET');
    },

    getAdminUsers: async (filters?: { 
        search?: string; 
        role?: string; 
        page?: number; 
        limit?: number 
    } = {}) => {
        const queryParams = new URLSearchParams();
        
        if (filters?.search) queryParams.append('search', filters.search);
        if (filters?.role) queryParams.append('role', filters.role);
        if (filters?.page) queryParams.append('page', (filters.page || 1).toString());
        if (filters?.limit) queryParams.append('limit', (filters.limit || 10).toString());

        const queryString = queryParams.toString();
        const url = queryString ? `/admin/users?${queryString}` : '/admin/users';
        
        return await apiCall(url, 'GET');
    },

    getAdminCourses: async (filters?: { 
        status?: string; 
        page?: number; 
        limit?: number 
    } = {}) => {
        const queryParams = new URLSearchParams();
        
        if (filters?.status) queryParams.append('status', filters.status);
        if (filters?.page) queryParams.append('page', (filters.page || 1).toString());
        if (filters?.limit) queryParams.append('limit', (filters.limit || 10).toString());

        const queryString = queryParams.toString();
        const url = queryString ? `/admin/courses?${queryString}` : '/admin/courses';
        
        return await apiCall(url, 'GET');
    },

    updateCourseStatus: async (courseId: string, status: boolean) => {
        if (!courseId) {
            throw new Error('Course ID is required');
        }
        
        return await apiCall(`/admin/courses/${courseId}/status`, 'PUT', { status });
    },

    createAdmin: async (adminData: any) => {
        if (!adminData.email || !adminData.password) {
            throw new Error('Email and password are required');
        }
        
        return await apiCall('/admin/create-admin', 'POST', adminData);
    },

    deleteUser: async (userId: string) => {
        if (!userId) {
            throw new Error('User ID is required');
        }
        
        return await apiCall(`/users/${userId}`, 'DELETE');
    },

    // New: Bulk actions
    bulkAction: async (action: string, ids: string[], data?: any) => {
        return await apiCall('/admin/bulk-action', 'POST', {
            action,
            ids,
            data
        });
    }
};

// Certificate functions
export const certificateAPI = {
    getCertificates: async () => {
        return await apiCall('/certificates', 'GET');
    },

    generateCertificate: async (courseId: string) => {
        if (!courseId) {
            throw new Error('Course ID is required');
        }
        
        return await apiCall('/certificates/generate', 'POST', { courseId });
    },

    verifyCertificate: async (certificateId: string) => {
        if (!certificateId) {
            throw new Error('Certificate ID is required');
        }
        
        return await apiCall(`/certificates/verify/${certificateId}`, 'GET');
    },

    downloadCertificate: async (certificateId: string) => {
        if (!certificateId) {
            throw new Error('Certificate ID is required');
        }
        
        return await apiCall(`/certificates/download/${certificateId}`, 'GET');
    },

    // New: Get certificate by course
    getCertificateByCourse: async (courseId: string) => {
        if (!courseId) {
            throw new Error('Course ID is required');
        }
        
        return await apiCall(`/certificates/course/${courseId}`, 'GET');
    }
};

// Study Hacks functions
export const studyHackAPI = {
    getStudyHacks: async (filters?: { 
        search?: string; 
        category?: string; 
        featured?: boolean;
        page?: number;
        limit?: number;
    } = {}) => {
        const queryParams = new URLSearchParams();
        
        if (filters?.search) queryParams.append('search', filters.search);
        if (filters?.category) queryParams.append('category', filters.category);
        if (filters?.featured) queryParams.append('featured', 'true');
        if (filters?.page) queryParams.append('page', (filters.page || 1).toString());
        if (filters?.limit) queryParams.append('limit', (filters.limit || 10).toString());

        const queryString = queryParams.toString();
        const url = queryString ? `/study-hacks?${queryString}` : '/study-hacks';
        
        return await apiCall(url, 'GET');
    },

    getFeaturedStudyHacks: async () => {
        return await apiCall('/study-hacks/featured', 'GET');
    },

    getStudyHackCategories: async () => {
        return await apiCall('/study-hacks/categories', 'GET');
    },

    createStudyHack: async (studyHackData: any) => {
        if (!studyHackData.title || !studyHackData.content) {
            throw new Error('Title and content are required');
        }
        
        return await apiCall('/study-hacks', 'POST', studyHackData);
    },

    likeStudyHack: async (studyHackId: string) => {
        if (!studyHackId) {
            throw new Error('Study hack ID is required');
        }
        
        return await apiCall(`/study-hacks/${studyHackId}/like`, 'POST');
    },

    // New: Get study hack by ID
    getStudyHack: async (studyHackId: string) => {
        if (!studyHackId) {
            throw new Error('Study hack ID is required');
        }
        
        return await apiCall(`/study-hacks/${studyHackId}`, 'GET');
    }
};

// Enhanced backend connection test
export const testBackend = async (): Promise<{ success: boolean; message: string }> => {
    try {
        console.log('🔄 Testing backend connection...');
        
        const response = await fetch('http://localhost:5000/api/health', {
            method: 'GET',
            headers: {
                'Content-Type': 'application/json',
            },
            // Add timeout
            signal: AbortSignal.timeout(5000)
        });
        
        if (!response.ok) {
            throw new Error(`Backend responded with status: ${response.status}`);
        }
        
        const data = await response.json();
        console.log('✅ Backend connection successful:', data);
        
        return {
            success: true,
            message: 'Backend is running properly'
        };
    } catch (error: any) {
        console.error('❌ Backend connection test failed:', error);
        
        if (error.name === 'TimeoutError') {
            throw new Error('Backend connection timeout. Server might be down or slow.');
        }
        
        if (error.message.includes('Failed to fetch')) {
            throw new Error('Cannot connect to backend server. Please make sure the backend is started on port 5000.');
        }
        
        throw new Error(`Backend test failed: ${error.message}`);
    }
};

// Enhanced utility function to check if user is admin
export const isAdmin = (): boolean => {
    if (typeof window === 'undefined') return false;
    
    try {
        const userData = localStorage.getItem('user');
        if (userData) {
            const user = JSON.parse(userData);
            return user.role === 'admin' || user.role === 'superadmin';
        }
    } catch (error) {
        console.error('Error parsing user data:', error);
    }
    return false;
};

// Enhanced utility function to get current user
export const getCurrentUser = (): any => {
    if (typeof window === 'undefined') return null;
    
    try {
        const userData = localStorage.getItem('user');
        return userData ? JSON.parse(userData) : null;
    } catch (error) {
        console.error('Error parsing user data:', error);
        return null;
    }
};

// Enhanced utility function to logout
export const logout = (): void => {
    if (typeof window === 'undefined') return;
    
    localStorage.removeItem('token');
    localStorage.removeItem('user');
    console.log('✅ User logged out successfully');
    
    // Optional: Redirect to login page
    if (window.location.pathname !== '/login') {
        window.location.href = '/login';
    }
};

// New: Check if user is authenticated
export const isAuthenticated = (): boolean => {
    if (typeof window === 'undefined') return false;
    
    const token = localStorage.getItem('token');
    const user = getCurrentUser();
    
    return !!(token && user);
};

// New: Set user data after login
export const setUserData = (user: any, token: string): void => {
    if (typeof window === 'undefined') return;
    
    localStorage.setItem('user', JSON.stringify(user));
    localStorage.setItem('token', token);
};

// New: Clear all auth data
export const clearAuthData = (): void => {
    if (typeof window === 'undefined') return;
    
    localStorage.removeItem('token');
    localStorage.removeItem('user');
    localStorage.removeItem('refreshToken');
};

export default {
    apiCall,
    authAPI,
    userAPI,
    courseAPI,
    adminAPI,
    certificateAPI,
    studyHackAPI,
    testBackend,
    isAdmin,
    getCurrentUser,
    logout,
    isAuthenticated,
    setUserData,
    clearAuthData
};