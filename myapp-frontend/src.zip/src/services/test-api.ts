import { testBackend, authAPI } from './api';

export const testAllAPIs = async () => {
    console.log('🧪 Testing API Connections...\n');

    try {
        // Test 1: Backend Health Check
        console.log('1. Testing backend connection...');
        const health = await testBackend();
        console.log('✅ Backend Health:', health);

        // Test 2: Admin Login
        console.log('\n2. Testing admin login...');
        const loginResponse = await authAPI.login(
            'raviramrajaboina@gmail.com',
            'ravi+shiva=143'
        );
        console.log('✅ Admin Login:', loginResponse.message);

        // Test 3: Get Courses
        console.log('\n3. Testing courses API...');
        const coursesResponse = await courseAPI.getCourses({ limit: 3 });
        console.log('✅ Courses loaded:', coursesResponse.data.length);

        console.log('\n🎉 All API tests passed! Frontend-Backend connection is working perfectly!');

    } catch (error: any) {
        console.error('\n❌ API Test Failed:', error.message);
    }
};

// Run tests when imported
testAllAPIs();