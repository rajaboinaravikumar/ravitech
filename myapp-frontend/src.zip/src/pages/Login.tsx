 import React, { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { Eye, EyeOff, Mail, Lock, X } from 'lucide-react';
import { useAuth } from '../context/AuthContext';
import { testBackend } from '../services/api';

const Login = () => {
  const [formData, setFormData] = useState({
    email: '',
    password: ''
  });
  const [showPassword, setShowPassword] = useState(false);
  const [isLoading, setIsLoading] = useState(false);
  const [error, setError] = useState('');
  const [backendStatus, setBackendStatus] = useState<'checking' | 'online' | 'offline' | null>(null);
  
  const { login } = useAuth();
  const navigate = useNavigate();

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setIsLoading(true);
    setError('');
    setBackendStatus('checking');

    try {
      // Test backend connection first
      console.log('🔄 Testing backend connection...');
      await testBackend();
      setBackendStatus('online');

      // Attempt login
      console.log('🔄 Attempting login...', formData);
      
      const success = await login(formData.email, formData.password);
      
      if (success) {
        console.log('✅ Login successful');
        
        // Redirect based on user role (handled in AuthContext)
        const userData = JSON.parse(localStorage.getItem('user') || '{}');
        if (userData.role === 'admin') {
          navigate('/admin-dashboard');
        } else {
          navigate('/dashboard');
        }
      } else {
        throw new Error('Login failed. Please check your credentials.');
      }
      
    } catch (error: any) {
      console.error('❌ Login failed:', error);
      setBackendStatus('offline');
      
      // Handle specific error cases
      if (error.message.includes('Cannot connect to server') || 
          error.message.includes('backend') ||
          error.message.includes('500')) {
        
        console.log('🔄 Backend offline, using AuthContext demo login...');
        // AuthContext will handle demo login automatically
        const success = await login(formData.email, formData.password);
        
        if (!success) {
          setError('Backend is offline and demo login failed. Please try again.');
        }
      } else {
        setError(error.message || 'Login failed. Please try again.');
      }
    } finally {
      setIsLoading(false);
    }
  };

  const handleChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    setFormData(prev => ({
      ...prev,
      [e.target.name]: e.target.value
    }));
    // Clear error when user starts typing
    if (error) setError('');
  };

  const handleClose = () => {
    navigate('/');
  };

  const switchToRegister = () => {
    navigate('/register');
  };

  // Pre-fill admin credentials for testing
  const fillAdminCredentials = () => {
    setFormData({
      email: 'raviramrajaboina@gmail.com',
      password: 'ravi+shiva=143'
    });
  };

  // Pre-fill student credentials for testing
  const fillStudentCredentials = () => {
    setFormData({
      email: 'student@example.com',
      password: 'password123'
    });
  };

  // Clear form
  const clearForm = () => {
    setFormData({
      email: '',
      password: ''
    });
    setError('');
  };

  // Demo login info
  const showDemoInfo = () => {
    alert(`Demo Login Credentials:
    
🛡️ ADMIN ACCESS:
Email: raviramrajaboina@gmail.com
Password: ravi+shiva=143

👨‍🎓 STUDENT ACCESS:
Email: any-email@example.com
Password: any-password

🔧 BACKEND STATUS:
• If backend is online: Real authentication
• If backend is offline: Demo mode auto-activated`);
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-black bg-opacity-50 backdrop-blur-sm">
      {/* Login Container */}
      <div className="bg-white dark:bg-gray-800 rounded-xl shadow-2xl border border-gray-200 dark:border-gray-700 p-6 mx-4 w-full max-w-sm relative">
        {/* Close Button */}
        <button
          onClick={handleClose}
          className="absolute -top-2 -right-2 bg-gray-200 dark:bg-gray-700 hover:bg-gray-300 dark:hover:bg-gray-600 rounded-full p-1 transition-colors duration-200 z-10"
        >
          <X className="h-5 w-5 text-gray-700 dark:text-gray-300" />
        </button>

        {/* Header */}
        <div className="text-center mb-6">
          <h2 className="text-2xl font-bold text-gray-900 dark:text-white">
            Welcome Back
          </h2>
          <p className="text-sm text-gray-600 dark:text-gray-400 mt-1">
            Sign in to your account
          </p>
        </div>

        {/* Backend Status Indicator */}
        {backendStatus && (
          <div className={`mb-3 p-2 rounded-lg text-xs text-center ${
            backendStatus === 'checking' ? 'bg-yellow-100 text-yellow-800' :
            backendStatus === 'online' ? 'bg-green-100 text-green-800' :
            'bg-red-100 text-red-800'
          }`}>
            {backendStatus === 'checking' && '🔄 Checking backend connection...'}
            {backendStatus === 'online' && '✅ Backend connected - Using real authentication'}
            {backendStatus === 'offline' && '⚠️ Using demo mode (Backend offline)'}
          </div>
        )}

        {/* Error Message */}
        {error && (
          <div className="mb-4 p-3 bg-red-100 border border-red-400 text-red-700 rounded-lg text-sm">
            {error}
          </div>
        )}

        {/* Quick Test Buttons */}
        <div className="mb-4 space-y-2">
          <button
            type="button"
            onClick={fillAdminCredentials}
            className="w-full text-xs py-1 px-2 bg-purple-100 text-purple-700 rounded border border-purple-300 hover:bg-purple-200 transition-colors"
          >
            🛡️ Fill Admin Credentials
          </button>
          <button
            type="button"
            onClick={fillStudentCredentials}
            className="w-full text-xs py-1 px-2 bg-blue-100 text-blue-700 rounded border border-blue-300 hover:bg-blue-200 transition-colors"
          >
            👨‍🎓 Fill Student Credentials
          </button>
          <button
            type="button"
            onClick={clearForm}
            className="w-full text-xs py-1 px-2 bg-gray-100 text-gray-700 rounded border border-gray-300 hover:bg-gray-200 transition-colors"
          >
            🗑️ Clear Form
          </button>
          <button
            type="button"
            onClick={showDemoInfo}
            className="w-full text-xs py-1 px-2 bg-yellow-100 text-yellow-700 rounded border border-yellow-300 hover:bg-yellow-200 transition-colors"
          >
            ℹ️ Demo Login Info
          </button>
        </div>
        
        <form className="space-y-4" onSubmit={handleSubmit}>
          {/* Email Input */}
          <div>
            <label htmlFor="email" className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-1">
              Email Address *
            </label>
            <div className="relative">
              <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none">
                <Mail className="h-4 w-4 text-gray-400" />
              </div>
              <input
                id="email"
                name="email"
                type="email"
                autoComplete="email"
                required
                value={formData.email}
                onChange={handleChange}
                className="block w-full pl-9 pr-3 py-2 text-sm border border-gray-300 dark:border-gray-600 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent bg-white dark:bg-gray-800 text-gray-900 dark:text-white placeholder-gray-500 dark:placeholder-gray-400 transition-colors duration-200"
                placeholder="Enter your email"
                disabled={isLoading}
              />
            </div>
          </div>

          {/* Password Input */}
          <div>
            <label htmlFor="password" className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-1">
              Password *
            </label>
            <div className="relative">
              <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none">
                <Lock className="h-4 w-4 text-gray-400" />
              </div>
              <input
                id="password"
                name="password"
                type={showPassword ? 'text' : 'password'}
                autoComplete="current-password"
                required
                value={formData.password}
                onChange={handleChange}
                className="block w-full pl-9 pr-9 py-2 text-sm border border-gray-300 dark:border-gray-600 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent bg-white dark:bg-gray-800 text-gray-900 dark:text-white placeholder-gray-500 dark:placeholder-gray-400 transition-colors duration-200"
                placeholder="Enter your password"
                disabled={isLoading}
              />
              <button
                type="button"
                onClick={() => setShowPassword(!showPassword)}
                className="absolute inset-y-0 right-0 pr-3 flex items-center hover:bg-gray-100 dark:hover:bg-gray-700 rounded-md p-1 transition-colors duration-200"
                disabled={isLoading}
              >
                {showPassword ? (
                  <EyeOff className="h-4 w-4 text-gray-400 hover:text-gray-600" />
                ) : (
                  <Eye className="h-4 w-4 text-gray-400 hover:text-gray-600" />
                )}
              </button>
            </div>
          </div>

          {/* Remember Me & Forgot Password */}
          <div className="flex items-center justify-between">
            <div className="flex items-center">
              <input
                id="remember-me"
                name="remember-me"
                type="checkbox"
                className="h-4 w-4 text-blue-600 focus:ring-blue-500 border-gray-300 rounded"
              />
              <label htmlFor="remember-me" className="ml-2 block text-sm text-gray-700 dark:text-gray-300">
                Remember me
              </label>
            </div>

            <button
              type="button"
              className="text-sm text-blue-600 hover:text-blue-500 dark:text-blue-400 dark:hover:text-blue-300 transition-colors duration-200"
            >
              Forgot password?
            </button>
          </div>

          {/* Submit Button */}
          <div className="pt-1">
            <button
              type="submit"
              disabled={isLoading}
              className="group relative w-full flex justify-center py-2 px-4 border border-transparent text-sm font-medium rounded-lg text-white bg-blue-600 hover:bg-blue-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-blue-500 disabled:opacity-50 disabled:cursor-not-allowed transition-colors duration-200 shadow-md hover:shadow-lg"
            >
              {isLoading ? (
                <div className="flex items-center">
                  <div className="animate-spin rounded-full h-4 w-4 border-b-2 border-white mr-2"></div>
                  {backendStatus === 'checking' ? 'Checking...' : 'Signing in...'}
                </div>
              ) : (
                'Sign in to your account'
              )}
            </button>
          </div>

          {/* Divider */}
          <div className="relative py-2">
            <div className="absolute inset-0 flex items-center">
              <div className="w-full border-t border-gray-300 dark:border-gray-600"></div>
            </div>
            <div className="relative flex justify-center text-sm">
              <span className="px-2 bg-white dark:bg-gray-800 text-gray-500 dark:text-gray-400">Or</span>
            </div>
          </div>

          {/* Google Sign In */}
          <div>
            <button
              type="button"
              disabled={isLoading}
              className="w-full flex justify-center items-center py-2 px-4 border border-gray-300 dark:border-gray-600 rounded-lg text-sm font-medium text-gray-700 dark:text-gray-300 bg-white dark:bg-gray-800 hover:bg-gray-50 dark:hover:bg-gray-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-blue-500 disabled:opacity-50 disabled:cursor-not-allowed transition-colors duration-200 shadow-sm hover:shadow-md"
            >
              <svg className="w-4 h-4 mr-2" viewBox="0 0 24 24">
                <path fill="#4285F4" d="M22.56 12.25c0-.78-.07-1.53-.2-2.25H12v4.26h5.92c-.26 1.37-1.04 2.53-2.21 3.31v2.77h3.57c2.08-1.92 3.28-4.74 3.28-8.09z"/>
                <path fill="#34A853" d="M12 23c2.97 0 5.46-.98 7.28-2.66l-3.57-2.77c-.98.66-2.23 1.06-3.71 1.06-2.86 0-5.29-1.93-6.16-4.53H2.18v2.84C3.99 20.53 7.7 23 12 23z"/>
                <path fill="#FBBC05" d="M5.84 14.09c-.22-.66-.35-1.36-.35-2.09s.13-1.43.35-2.09V7.07H2.18C1.43 8.55 1 10.22 1 12s.43 3.45 1.18 4.93l2.85-2.22.81-.62z"/>
                <path fill="#EA4335" d="M12 5.38c1.62 0 3.06.56 4.21 1.64l3.15-3.15C17.45 2.09 14.97 1 12 1 7.7 1 3.99 3.47 2.18 7.07l3.66 2.84c.87-2.6 3.3-4.53 6.16-4.53z"/>
              </svg>
              Continue with Google
            </button>
          </div>
        </form>

        {/* Register Link */}
        <div className="text-center pt-4">
          <p className="text-sm text-gray-600 dark:text-gray-400">
            Don't have an account?{' '}
            <button 
              onClick={switchToRegister}
              className="font-medium text-blue-600 hover:text-blue-500 dark:text-blue-400 dark:hover:text-blue-300 transition-colors duration-200"
              disabled={isLoading}
            >
              Sign up here
            </button>
          </p>
        </div>

        {/* Demo Information */}
        <div className="mt-4 p-3 bg-gray-50 dark:bg-gray-700 rounded-lg">
          <p className="text-xs text-gray-600 dark:text-gray-400 text-center">
            <strong>Demo Mode:</strong> Works offline with any email/password<br/>
            <strong>Admin Access:</strong> Use admin credentials above
          </p>
        </div>
      </div>
    </div>
  );
};

export default Login;