import React from 'react';
import { Download, Share2, Award, Calendar } from 'lucide-react';
import { useAuth } from '../contexts/AuthContext';
import toast from 'react-hot-toast';

const Certificates = () => {
  const { user } = useAuth();

  const handleDownload = (courseName: string) => {
    // In a real app, this would generate and download a PDF
    toast.success(`Certificate for ${courseName} downloaded!`);
  };

  const handleShare = (courseName: string) => {
    // In a real app, this would share the certificate
    toast.success(`Certificate for ${courseName} shared!`);
  };

  const completedCourses = [
    {
      id: 'python-basics',
      title: 'Python Fundamentals',
      completedDate: '2024-01-15',
      certificateId: 'PY-2024-001',
      instructor: 'Ravi Ram'
    }
  ].filter(course => {
    if (!user) return false;
    const progress = user.progress[course.id];
    return progress && progress.length >= 8; // Assuming 8 topics for completion
  });

  if (!user) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <div className="text-center">
          <h2 className="text-2xl font-bold text-gray-900 dark:text-white mb-4">
            Please log in to view your certificates
          </h2>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen py-8">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        {/* Header */}
        <div className="text-center mb-12">
          <h1 className="text-4xl font-bold text-gray-900 dark:text-white mb-4">
            My Certificates
          </h1>
          <p className="text-xl text-gray-600 dark:text-gray-300 max-w-3xl mx-auto">
            Showcase your achievements and download your course completion certificates
          </p>
        </div>

        {/* Stats */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-12">
          <div className="bg-white dark:bg-gray-800 p-6 rounded-xl shadow-lg text-center">
            <Award className="h-12 w-12 text-yellow-500 mx-auto mb-4" />
            <div className="text-3xl font-bold text-gray-900 dark:text-white mb-2">
              {completedCourses.length}
            </div>
            <div className="text-gray-600 dark:text-gray-400">Certificates Earned</div>
          </div>
          
          <div className="bg-white dark:bg-gray-800 p-6 rounded-xl shadow-lg text-center">
            <Calendar className="h-12 w-12 text-blue-500 mx-auto mb-4" />
            <div className="text-3xl font-bold text-gray-900 dark:text-white mb-2">
              {user.enrolledCourses.length}
            </div>
            <div className="text-gray-600 dark:text-gray-400">Courses Enrolled</div>
          </div>
          
          <div className="bg-white dark:bg-gray-800 p-6 rounded-xl shadow-lg text-center">
            <Share2 className="h-12 w-12 text-green-500 mx-auto mb-4" />
            <div className="text-3xl font-bold text-gray-900 dark:text-white mb-2">
              {completedCourses.length}
            </div>
            <div className="text-gray-600 dark:text-gray-400">Shared Certificates</div>
          </div>
        </div>

        {/* Certificates Grid */}
        {completedCourses.length === 0 ? (
          <div className="text-center py-16">
            <Award className="h-24 w-24 text-gray-400 mx-auto mb-6" />
            <h3 className="text-2xl font-bold text-gray-900 dark:text-white mb-4">
              No certificates yet
            </h3>
            <p className="text-gray-600 dark:text-gray-400 mb-8 max-w-md mx-auto">
              Complete your courses to earn certificates and showcase your achievements
            </p>
            <a
              href="/courses"
              className="inline-flex items-center px-6 py-3 bg-blue-600 text-white rounded-lg hover:bg-blue-700 transition-colors"
            >
              Browse Courses
            </a>
          </div>
        ) : (
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
            {completedCourses.map((course) => (
              <div key={course.id} className="bg-white dark:bg-gray-800 rounded-xl shadow-lg border border-gray-200 dark:border-gray-700 overflow-hidden">
                {/* Certificate Preview */}
                <div className="relative h-48 bg-gradient-to-br from-blue-600 to-purple-600 p-6 text-white">
                  <div className="absolute top-4 right-4">
                    <Award className="h-8 w-8 text-yellow-300" />
                  </div>
                  <div className="h-full flex flex-col justify-center">
                    <div className="text-center">
                      <h3 className="text-lg font-bold mb-2">Certificate of Completion</h3>
                      <p className="text-sm opacity-90 mb-1">{course.title}</p>
                      <p className="text-xs opacity-75">{user.name}</p>
                    </div>
                  </div>
                  <div className="absolute bottom-4 left-6 text-xs opacity-75">
                    ID: {course.certificateId}
                  </div>
                </div>

                {/* Certificate Details */}
                <div className="p-6">
                  <div className="mb-4">
                    <h4 className="font-semibold text-gray-900 dark:text-white mb-2">
                      {course.title}
                    </h4>
                    <div className="flex items-center text-sm text-gray-600 dark:text-gray-400 mb-1">
                      <Calendar className="h-4 w-4 mr-2" />
                      Completed: {new Date(course.completedDate).toLocaleDateString()}
                    </div>
                    <div className="text-sm text-gray-600 dark:text-gray-400">
                      Instructor: {course.instructor}
                    </div>
                  </div>

                  {/* Actions */}
                  <div className="flex space-x-2">
                    <button
                      onClick={() => handleDownload(course.title)}
                      className="flex-1 flex items-center justify-center px-4 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700 transition-colors"
                    >
                      <Download className="h-4 w-4 mr-2" />
                      Download
                    </button>
                    <button
                      onClick={() => handleShare(course.title)}
                      className="flex items-center justify-center px-4 py-2 bg-gray-200 dark:bg-gray-700 text-gray-700 dark:text-gray-300 rounded-lg hover:bg-gray-300 dark:hover:bg-gray-600 transition-colors"
                    >
                      <Share2 className="h-4 w-4" />
                    </button>
                  </div>
                </div>
              </div>
            ))}
          </div>
        )}

        {/* Share Section */}
        {completedCourses.length > 0 && (
          <div className="mt-16 bg-gray-50 dark:bg-gray-800 rounded-2xl p-8 text-center">
            <h2 className="text-2xl font-bold text-gray-900 dark:text-white mb-4">
              Share Your Achievements
            </h2>
            <p className="text-gray-600 dark:text-gray-400 mb-6 max-w-2xl mx-auto">
              Let the world know about your programming skills! Share your certificates on social media 
              and professional networks to showcase your learning journey.
            </p>
            <div className="flex justify-center space-x-4">
              <button className="px-6 py-3 bg-blue-600 text-white rounded-lg hover:bg-blue-700 transition-colors">
                Share on LinkedIn
              </button>
              <button className="px-6 py-3 bg-gray-800 dark:bg-gray-700 text-white rounded-lg hover:bg-gray-900 dark:hover:bg-gray-600 transition-colors">
                Share on Twitter
              </button>
            </div>
          </div>
        )}
      </div>
    </div>
  );
};

export default Certificates;