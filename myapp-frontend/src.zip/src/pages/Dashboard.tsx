import React from 'react';
import { Link } from 'react-router-dom';
import { BookOpen, Award, TrendingUp, Clock, CheckCircle, Play } from 'lucide-react';
import { useAuth } from '../contexts/AuthContext';

const Dashboard = () => {
  const { user } = useAuth();

  if (!user) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <div className="text-center">
          <h2 className="text-2xl font-bold text-gray-900 dark:text-white mb-4">
            Please log in to access your dashboard
          </h2>
          <Link to="/login" className="text-blue-600 hover:text-blue-500">
            Go to Login
          </Link>
        </div>
      </div>
    );
  }

  const enrolledCourses = [
    {
      id: 'python-basics',
      title: 'Python Fundamentals',
      progress: ((user.progress['python-basics']?.length || 0) / 8) * 100,
      totalTopics: 8,
      completedTopics: user.progress['python-basics']?.length || 0,
      lastAccessed: '2 hours ago',
      color: 'from-blue-500 to-blue-600'
    },
    {
      id: 'java-programming',
      title: 'Java Programming',
      progress: ((user.progress['java-programming']?.length || 0) / 6) * 100,
      totalTopics: 6,
      completedTopics: user.progress['java-programming']?.length || 0,
      lastAccessed: '1 day ago',
      color: 'from-teal-500 to-teal-600'
    }
  ].filter(course => user.enrolledCourses.includes(course.id));

  const completedCourses = enrolledCourses.filter(course => course.progress === 100);
  const totalProgress = enrolledCourses.length > 0 
    ? enrolledCourses.reduce((sum, course) => sum + course.progress, 0) / enrolledCourses.length 
    : 0;

  return (
    <div className="mt-20 min-h-screen bg-gray-50 dark:bg-gray-900 flex relative overflow-hidden">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        {/* Header */}
        <div className="mb-8">
          <h1 className="text-3xl font-bold text-gray-900 dark:text-white mb-2">
            Welcome back, {user.name}!
          </h1>
          <p className="text-gray-600 dark:text-gray-400">
            Continue your learning journey and track your progress
          </p>
        </div>

        {/* Stats Grid */}
        <div className="grid grid-cols-1 md:grid-cols-4 gap-6 mb-8">
          <div className="bg-white dark:bg-gray-800 p-6 rounded-xl shadow-lg border border-gray-200 dark:border-gray-700">
            <div className="flex items-center">
              <div className="p-2 bg-blue-100 dark:bg-blue-900 rounded-lg mr-4">
                <BookOpen className="h-6 w-6 text-blue-600 dark:text-blue-400" />
              </div>
              <div>
                <p className="text-2xl font-bold text-gray-900 dark:text-white">{enrolledCourses.length}</p>
                <p className="text-gray-600 dark:text-gray-400 text-sm">Enrolled Courses</p>
              </div>
            </div>
          </div>

          <div className="bg-white dark:bg-gray-800 p-6 rounded-xl shadow-lg border border-gray-200 dark:border-gray-700">
            <div className="flex items-center">
              <div className="p-2 bg-green-100 dark:bg-green-900 rounded-lg mr-4">
                <CheckCircle className="h-6 w-6 text-green-600 dark:text-green-400" />
              </div>
              <div>
                <p className="text-2xl font-bold text-gray-900 dark:text-white">{completedCourses.length}</p>
                <p className="text-gray-600 dark:text-gray-400 text-sm">Completed Courses</p>
              </div>
            </div>
          </div>

          <div className="bg-white dark:bg-gray-800 p-6 rounded-xl shadow-lg border border-gray-200 dark:border-gray-700">
            <div className="flex items-center">
              <div className="p-2 bg-purple-100 dark:bg-purple-900 rounded-lg mr-4">
                <TrendingUp className="h-6 w-6 text-purple-600 dark:text-purple-400" />
              </div>
              <div>
                <p className="text-2xl font-bold text-gray-900 dark:text-white">{Math.round(totalProgress)}%</p>
                <p className="text-gray-600 dark:text-gray-400 text-sm">Average Progress</p>
              </div>
            </div>
          </div>

          <div className="bg-white dark:bg-gray-800 p-6 rounded-xl shadow-lg border border-gray-200 dark:border-gray-700">
            <div className="flex items-center">
              <div className="p-2 bg-orange-100 dark:bg-orange-900 rounded-lg mr-4">
                <Award className="h-6 w-6 text-orange-600 dark:text-orange-400" />
              </div>
              <div>
                <p className="text-2xl font-bold text-gray-900 dark:text-white">{completedCourses.length}</p>
                <p className="text-gray-600 dark:text-gray-400 text-sm">Certificates Earned</p>
              </div>
            </div>
          </div>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
          {/* My Courses */}
          <div className="lg:col-span-2">
            <div className="bg-white dark:bg-gray-800 rounded-xl shadow-lg border border-gray-200 dark:border-gray-700 p-6">
              <h2 className="text-xl font-bold text-gray-900 dark:text-white mb-6">My Courses</h2>
              
              {enrolledCourses.length === 0 ? (
                <div className="text-center py-12">
                  <BookOpen className="h-12 w-12 text-gray-400 mx-auto mb-4" />
                  <h3 className="text-lg font-medium text-gray-900 dark:text-white mb-2">
                    No courses enrolled yet
                  </h3>
                  <p className="text-gray-600 dark:text-gray-400 mb-4">
                    Start your learning journey by exploring our courses
                  </p>
                  <Link
                    to="/courses"
                    className="inline-flex items-center px-4 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700 transition-colors"
                  >
                    Browse Courses
                  </Link>
                </div>
              ) : (
                <div className="space-y-4">
                  {enrolledCourses.map((course) => (
                    <div key={course.id} className="border border-gray-200 dark:border-gray-700 rounded-lg p-4 hover:shadow-md transition-shadow">
                      <div className="flex items-center justify-between mb-3">
                        <h3 className="font-semibold text-gray-900 dark:text-white">{course.title}</h3>
                        <Link
                          to={`/course/${course.id}`}
                          className="flex items-center px-3 py-1 bg-blue-600 text-white text-sm rounded-lg hover:bg-blue-700 transition-colors"
                        >
                          <Play className="h-4 w-4 mr-1" />
                          Continue
                        </Link>
                      </div>
                      
                      <div className="mb-3">
                        <div className="flex justify-between text-sm text-gray-600 dark:text-gray-400 mb-1">
                          <span>Progress: {course.completedTopics}/{course.totalTopics} topics</span>
                          <span>{Math.round(course.progress)}%</span>
                        </div>
                        <div className="w-full bg-gray-200 dark:bg-gray-700 rounded-full h-2">
                          <div
                            className={`h-2 rounded-full bg-gradient-to-r ${course.color} transition-all duration-300`}
                            style={{ width: `${course.progress}%` }}
                          />
                        </div>
                      </div>
                      
                      <div className="flex items-center text-sm text-gray-500 dark:text-gray-400">
                        <Clock className="h-4 w-4 mr-1" />
                        Last accessed: {course.lastAccessed}
                      </div>
                    </div>
                  ))}
                </div>
              )}
            </div>
          </div>

          {/* Quick Actions & Achievements */}
          <div className="space-y-6">
            {/* Quick Actions */}
            <div className="bg-white dark:bg-gray-800 rounded-xl shadow-lg border border-gray-200 dark:border-gray-700 p-6">
              <h3 className="text-lg font-semibold text-gray-900 dark:text-white mb-4">Quick Actions</h3>
              <div className="space-y-3">
                <Link
                  to="/courses"
                  className="flex items-center p-3 rounded-lg hover:bg-gray-50 dark:hover:bg-gray-700 transition-colors"
                >
                  <BookOpen className="h-5 w-5 text-blue-600 mr-3" />
                  <span className="text-gray-700 dark:text-gray-300">Browse Courses</span>
                </Link>
                <Link
                  to="/certificates"
                  className="flex items-center p-3 rounded-lg hover:bg-gray-50 dark:hover:bg-gray-700 transition-colors"
                >
                  <Award className="h-5 w-5 text-purple-600 mr-3" />
                  <span className="text-gray-700 dark:text-gray-300">My Certificates</span>
                </Link>
                <Link
                  to="/study-hacks"
                  className="flex items-center p-3 rounded-lg hover:bg-gray-50 dark:hover:bg-gray-700 transition-colors"
                >
                  <TrendingUp className="h-5 w-5 text-green-600 mr-3" />
                  <span className="text-gray-700 dark:text-gray-300">Study Hacks</span>
                </Link>
              </div>
            </div>

            {/* Recent Achievements */}
            <div className="bg-white dark:bg-gray-800 rounded-xl shadow-lg border border-gray-200 dark:border-gray-700 p-6">
              <h3 className="text-lg font-semibold text-gray-900 dark:text-white mb-4">Recent Achievements</h3>
              {completedCourses.length === 0 ? (
                <p className="text-gray-600 dark:text-gray-400 text-sm">
                  Complete your first course to earn achievements!
                </p>
              ) : (
                <div className="space-y-3">
                  {completedCourses.slice(0, 3).map((course) => (
                    <div key={course.id} className="flex items-center p-3 bg-green-50 dark:bg-green-900/20 rounded-lg">
                      <Award className="h-5 w-5 text-green-600 mr-3" />
                      <div>
                        <p className="font-medium text-green-800 dark:text-green-200 text-sm">
                          Completed {course.title}
                        </p>
                        <p className="text-green-600 dark:text-green-400 text-xs">
                          Certificate earned!
                        </p>
                      </div>
                    </div>
                  ))}
                </div>
              )}
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default Dashboard;